<head>
    <meta charset="UTF-8">
    <title>Fomulário HTML - Curso PHP - eXcript</title>
</head>
<?php
$nome = $_POST["nome"];
$celular = $_POST["celular"];
$data = $_POST["data"];
$cep = $_POST["cep"];
$endereco = $_POST["endereco"];
$cidade = $_POST["cidade"];
$estado = $_POST["estado"];
$email = $_POST["email"];

include 'lista1.php';
echo 'Nome: ' . $nome . "<br>";
 echo 'Celular: ' . $celular . "<br>";
 echo 'Data De nasc.: ' . $data . "<br>";
 echo 'Cep: ' . $cep . "<br>";
 echo 'Endereço: ' .$endereco  . "<br>";
 echo 'Cidade: ' .$cidade  . "<br>";
 echo 'Estado: ' . $cep . "<br>";
 echo 'E-mail: ' . $email . "<br>";
?>