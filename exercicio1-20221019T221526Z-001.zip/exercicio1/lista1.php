<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Fomulário HTML - Curso PHP - eXcript</title>
</head>
<body>

<form action="pg2.php?xget=50" method="POST">

    <fieldset>
        <legend>Formulário HTML</legend>

        <p>
            <label for="nome">Nome: </label>
            <input type="text" name="nome" id="nome">
        </p>

        <p>
            <label for="celular">Celular: </label>
            <input type="number" name="celular" id="celular">
        </p>

        <p>
            <label for="data">Data nascimento: </label>
            <input type="date" name="data" id="data">
        </p>
    
        <p>
            <label for="cep">Cep: </label>
            <input type="number" name="cep" id="cep">
        </p>

        <p>
            <label for="endereco">Endereço: </label>
            <input type="text" name="endereco" id="endereco">
        </p>

        <p>
            <label for="cidade">Cidade: </label>
            <input type="text" name="cidade" id="cidade">
        </p>
        <p>
            <label for="estado">Estado: </label>
            <input type="text" name="estado" id="estado">
        </p>
        <p>
            <label for="email">E-mail: </label>
            <input type="email" name="email" id="email">
        </p>

    </fieldset>

    <p>
        <button type="submit">Enviar sua mensagem</button>
    </p>

    


</form>


</body>
</html>


